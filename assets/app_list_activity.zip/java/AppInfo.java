package com.example.emptyapp;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

public class AppInfo {

    // The application info from package manager
    public ApplicationInfo applicationInfo;

    public String packageName;
    public String appName;


    public AppInfo(PackageManager pm, ApplicationInfo info) {
        this.applicationInfo = info;
        this.packageName = info.packageName;
        this.appName = (String) info.loadLabel(pm);
    }
}