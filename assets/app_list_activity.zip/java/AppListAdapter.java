package com.example.emptyapp;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AppListAdapter extends BaseAdapter {

    public final List<AppInfo> appList = new ArrayList<AppInfo>();
    private Context ctx;
    private PackageManager pm;

    private LruCache<String, Drawable> iconCache = new LruCache<String, Drawable>(32) {
        protected void entryRemoved(
                boolean evicted, String key, Drawable oldValue, Drawable newValue) {
            oldValue.setCallback(null);
        }
    };

    public AppListAdapter(Context ctx) {
        this.ctx = ctx;
        this.pm = ctx.getPackageManager();
    }

    public void setAppList(List<AppInfo> appList) {
        synchronized (this.appList) {
            this.appList.clear();
            this.appList.addAll(appList);
        }
    }

    @Override
    public int getCount() {
        synchronized (this.appList) {
            return this.appList.size();
        }
    }

    @Override
    public Object getItem(int position) {
        synchronized (this.appList) {
            return this.appList.get(position);
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        AppInfo appInfo = (AppInfo) getItem(position);
        if (appInfo == null) {
            return null;
        }

        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(ctx).inflate(R.layout.item_applist, null);
            viewHolder = new ViewHolder();
            viewHolder.icon = (ImageView) convertView.findViewById(R.id.app_icon);
            viewHolder.appName = (TextView) convertView.findViewById(R.id.app_name);
            viewHolder.pkgName = (TextView) convertView.findViewById(R.id.app_pkgname);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        try {
            viewHolder.appName.setText(appInfo.appName);
            viewHolder.pkgName.setText(appInfo.packageName);

            Drawable icon = iconCache.get(appInfo.packageName);
            if (icon == null) {
                icon = appInfo.applicationInfo.loadIcon(pm);
                iconCache.put(appInfo.packageName, icon);
            }

            viewHolder.icon.setImageDrawable(icon);
        } catch (Throwable t) {
            t.printStackTrace();
        }

        return convertView;
    }

    private static class ViewHolder {
        public ImageView icon;
        public TextView appName;
        public TextView pkgName;
    }
}