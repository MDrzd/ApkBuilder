package com.example.emptyapp;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private AppListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView appListView = (ListView) findViewById(R.id.app_list);
        this.adapter = new AppListAdapter(this);
        appListView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        new Thread() {
            @Override
            public void run() {
                List<AppInfo> appList = getAppList();
                updateAppList(appList);
            }
        }.start();
    }

    private void updateAppList(final List<AppInfo> appList) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.setAppList(appList);
                adapter.notifyDataSetChanged();
            }
        });
    }

    private List<AppInfo> getAppList() {
        List<AppInfo> appList = new ArrayList<>();

        PackageManager pm = getPackageManager();
        List<ApplicationInfo> appInfoList = pm.getInstalledApplications(0);

        // Only show user apps
        for (ApplicationInfo info : appInfoList) {
            if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                appList.add(new AppInfo(pm, info));
            }
        }

        return appList;
    }
}
