package com.example.emptyapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {

	protected void onCreate(Bundle paramBundle) {
		super.onCreate(paramBundle);
		setLiveWP();
	}

	protected void setLiveWP() {
		startActivity(new Intent(
				"android.service.wallpaper.LIVE_WALLPAPER_CHOOSER"));
		finish();
	}

}