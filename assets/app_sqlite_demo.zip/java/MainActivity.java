package com.example.emptyapp;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity implements View.OnClickListener {

    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.dbManager = new DBManager(this);
        initView();
    }

    @Override
    protected void onDestroy() {
        dbManager.closeDB();
        super.onDestroy();
    }

    private void initView() {
        findViewById(R.id.btn_add).setOnClickListener(this);
        findViewById(R.id.btn_remove).setOnClickListener(this);
        findViewById(R.id.btn_revise).setOnClickListener(this);
        findViewById(R.id.btn_query).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btn_add) {
            addRecord();
        } else if (id == R.id.btn_remove) {
            removeRecord();
        } else if (id == R.id.btn_revise) {
            reviseRecord();
        } else if (id == R.id.btn_query) {
            queryRecords();
        }
    }

    private void queryRecords() {
        List<AppRecord> records = dbManager.query();

        StringBuilder sb = new StringBuilder();
        sb.append(String.valueOf(records.size()));
        sb.append(" Records");
        if (!records.isEmpty()) {
            sb.append(":\n");
        }
        for (AppRecord rec : records) {
            sb.append(rec.label);
            sb.append("\n");
        }

        Toast.makeText(this, sb.toString(), Toast.LENGTH_LONG).show();
    }

    private void reviseRecord() {
        AppRecord record = new AppRecord();
        ApplicationInfo appInfo = getApplicationInfo();
        record.packageName = appInfo.packageName;
        record.label = "Revised";
        record.apkPath = appInfo.sourceDir;

        int revised = dbManager.updateRecord(record);
        String message = String.format("Revised %d record(s)", revised);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void removeRecord() {
        int deleted = dbManager.deleteOldRecord(getPackageName());
        String message = String.format("Removed %d record(s)", deleted);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void addRecord() {
        try {
            AppRecord record = new AppRecord();
            ApplicationInfo appInfo = getApplicationInfo();
            record.packageName = appInfo.packageName;
            record.label = getPackageManager().getApplicationLabel(appInfo).toString();
            record.apkPath = appInfo.sourceDir;
            dbManager.add(record);
            Toast.makeText(this, "Added a record", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
