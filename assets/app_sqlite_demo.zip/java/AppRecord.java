package com.example.emptyapp;

public class AppRecord {
	public int _id;
	public String packageName;
	public String label;
	public String apkPath;
}
