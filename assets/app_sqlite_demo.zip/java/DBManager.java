package com.example.emptyapp;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DBManager {
    private SQLiteDatabase db;

    public DBManager(Context context) {
        DBHelper helper = new DBHelper(context);
        db = helper.getWritableDatabase();
    }

    public void add(List<AppRecord> recordList) {
        db.beginTransaction();
        try {
            for (AppRecord record : recordList) {
                db.execSQL("INSERT INTO apps VALUES(null, ?, ?, ?)",
                        new Object[]{record.packageName, record.label, record.apkPath});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    // Add a record
    public void add(AppRecord record) {
        db.execSQL("INSERT INTO apps VALUES(null, ?, ?, ?)",
                new Object[]{record.packageName, record.label, record.apkPath});
    }

    // Update record according to package name
    public int updateRecord(AppRecord record) {
        ContentValues cv = new ContentValues();
        cv.put("label", record.label);
        cv.put("apk_path", record.apkPath);
        return db.update("apps", cv, "package_name = ?",
                new String[]{record.packageName});
    }

    // Remove record according to package name
    public int deleteOldRecord(String packageName) {
        return db.delete("apps", "package_name = ?",
                new String[]{packageName});
    }

    // Query all the records
    public List<AppRecord> query() {
        ArrayList<AppRecord> recordList = new ArrayList<AppRecord>();
        Cursor c = db.rawQuery("SELECT * FROM apps", null);
        while (c.moveToNext()) {
            AppRecord record = new AppRecord();
            record._id = c.getInt(c.getColumnIndex("_id"));
            record.packageName = c.getString(c.getColumnIndex("package_name"));
            record.label = c.getString(c.getColumnIndex("label"));
            record.apkPath = c.getString(c.getColumnIndex("apk_path"));
            recordList.add(record);
        }
        c.close();
        return recordList;
    }

    // Close database
    public void closeDB() {
        db.close();
    }
}
